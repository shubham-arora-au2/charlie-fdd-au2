import React from 'react';
import {connect} from 'react-redux';
import {BrowserRouter as Router, Route} from 'react-router-dom';
import Search from './Search'
import Header from './Header'
import BooksList from './Bookslist'

function App(props) {
  return (
    <Router>
    <div className="App">
      <header className="App-header">
        <Header />
        <Search />
      </header>
      {props.LoggedIn ? <BooksList /> : null}
    </div>
    </Router>
  );
}

const mapStateToProps = (state) => {
  console.log("LoggedIn ===> mapStateToProps");
  console.log(state.booksReducer.booksList);
  return {
    LoggedIn: localStorage.getItem('user')
   };
};

export default connect(mapStateToProps)(App);
