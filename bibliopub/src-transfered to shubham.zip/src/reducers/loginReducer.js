const loginReducer = (state={LoggedIn:JSON.parse(localStorage.getItem('user'))},action) => {
  JSON.parse(localStorage.getItem('user'))
  console.log("loginReducer");
  console.log(JSON.parse(localStorage.getItem('user')));
  switch (action.type) {
    case "LOGIN_USER":
      return Object.assign({}, state, {LoggedIn: localStorage.getItem('user')})
    case "LOGOUT_USER":
      return Object.assign({}, state, {LoggedIn: null})

    default: return state

  }
};

export default loginReducer;
