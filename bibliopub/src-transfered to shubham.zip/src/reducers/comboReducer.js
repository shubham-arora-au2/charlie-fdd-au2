import React from 'react';
import {combineReducers} from 'redux';
import booksReducer from './bookReducer';
import loginReducer from './loginReducer';

const comboReducer = combineReducers({
  booksReducer,
  loginReducer
})

export default comboReducer;
