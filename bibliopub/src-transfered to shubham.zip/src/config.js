const CONFIG = {
  API_KEY: "AIzaSyCOmvcyLWpKngvtokUUz0WA-RtYt_6eOgU"
}

export default CONFIG
